package homework;

/*
3.定义一个“点”（Point）类用来表示平面中的点（有两个坐标）。要求如下：
    1）可以生成具有特定坐标的点对象。
    2）提供可以设置两个坐标的方法。
    3）提供可以计算该“点”距原点距离的平方的方法
*/
public class Point {
    double x;
    double y;

    public Point(){}

    public Point(double x, double y){
        this.x = x;
        this.y = y;
    }

    public void setX(double x){
        this.x = x;
    }

    public void setY(double y){
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public String display(){
        //System.out.println("(" + x + ", " + y + ")");
        return "(" + x + ", " + y + ")";
    }

    // 计算该“点”距原点距离的平方的方法
    public double pointSquare(){
        //double square = 0.0;
        //square = x * x + y * y;
        return x * x + y * y;
    }
}
