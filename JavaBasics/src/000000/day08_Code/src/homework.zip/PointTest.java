package homework;

public class PointTest {

    public static void main(String[] args){

        PointTest test = new PointTest();
        Point p1 = new Point(1,2);
        Point p2 = new Point(3,4);
        Point p = new Point();

        System.out.println("点p1坐标：" + p1.display());
        System.out.println("点p2坐标：" + p2.display());


        // 生成具有特定坐标的点对象
        p.setX(11);
        p.setY(22);
        System.out.println("点p坐标：" + p.display());


        // 计算该“点”距原点距离的平方
        System.out.println("点p到原点的距离的平方：" + p.pointSquare());
    }

}
