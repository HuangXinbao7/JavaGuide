package homework;

public class Student {

    int id;
    String name;
    int grade;
    int score;

    public Student() {}

    public Student(int id, String name, int grade, int score) {
        this.id = id;
        this.name = name;
        this.grade = grade;
        this.score = score;
    }

    public String say(){
        return "id: " + id + ", 姓名：" + name + ", 年级： " + grade + ", 分数：" + score;
    }

    public static void main(String[] args){

        Student[] stu = new Student[10];

        for (int i = 0; i < 10; i++){

            int id = i + 1;
            String name = "小明";
            int grade = (int)(Math.random() * 6 + 1);
            int score = 10 + (int)(Math.random() * 90);

            stu[i] = new Student(id, name, grade, score);
        }

        for (int i = 0; i < 10; i++){
            System.out.println(stu[i].say());
        }
    }
}
